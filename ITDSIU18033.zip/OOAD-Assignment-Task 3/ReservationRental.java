package entity;

import java.util.Date;

public class ReservationRental {
    String status;
    Date exPickupDate;
    Date exPickupTime;

}
